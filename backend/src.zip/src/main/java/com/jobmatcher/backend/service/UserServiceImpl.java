package com.jobmatcher.backend.service;

import com.jobmatcher.backend.dto.request.CreateUserRequest;
import com.jobmatcher.backend.dto.response.UserResponse;
import com.jobmatcher.backend.entity.User;
import com.jobmatcher.backend.exception.UserNotFoundException;
import com.jobmatcher.backend.repository.UserRepository;
import com.jobmatcher.backend.security.JwtProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public User findUserByEmail(String email) throws Exception{
        return userRepository.findByEmail(email).orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    @Override
    public UserResponse saveUser(CreateUserRequest request) {

        User user = new User();

        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        User savedUser = userRepository.save(user);
        return new UserResponse(
                savedUser.getId(),
                savedUser.getName(),
                savedUser.getEmail()
        );
    }

    @Override
    public User getUserById(Long id) throws Exception {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    @Override
    public User updateUser(Long id, User user) throws Exception {
        User existingUser = getUserById(id);

        existingUser.setName(user.getName());
        existingUser.setEmail(user.getEmail());
        existingUser.setPassword(user.getPassword());
        existingUser.setResumeURL(user.getResumeURL());

        return userRepository.save(existingUser);
    }

    @Override
    public void deleteUser(Long id) throws Exception {
        User user = getUserById(id);
        userRepository.delete(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User findUserByJwtToken(String jwt) throws Exception {

        if (jwt == null || !jwt.startsWith("Bearer ")) {
            throw new UserNotFoundException("Invalid JWT token");
        }

        String token = jwt.substring(7);

        String email = JwtProvider.getEmailFromToken(token);

        return findUserByEmail(email);
    }
}
