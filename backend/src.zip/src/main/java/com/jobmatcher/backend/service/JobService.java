package com.jobmatcher.backend.service;

import com.jobmatcher.backend.dto.request.CreateJobRequest;
import com.jobmatcher.backend.dto.response.JobResponse;
import com.jobmatcher.backend.dto.response.RecommendedJobResponse;
import com.jobmatcher.backend.entity.Job;

import java.util.List;

public interface JobService {


    JobResponse createJob(CreateJobRequest request);

    Job getJobById(Long id) throws Exception;

    Job updateJob(Long id, Job job) throws Exception;
    List<Job> getAllJobs();

    List<RecommendedJobResponse> getRecommendedJobsForUser(Long userId) throws Exception;

    void deleteJob(Long id);

}
