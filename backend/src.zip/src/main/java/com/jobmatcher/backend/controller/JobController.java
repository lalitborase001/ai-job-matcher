package com.jobmatcher.backend.controller;

import com.jobmatcher.backend.dto.request.CreateJobRequest;
import com.jobmatcher.backend.dto.response.JobResponse;
import com.jobmatcher.backend.entity.Job;
import com.jobmatcher.backend.entity.User;
import com.jobmatcher.backend.service.JobService;
import com.jobmatcher.backend.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/jobs")
@Tag(name = "Job API", description = "Operations related to job")
public class JobController {

    private final JobService jobService;
    private final UserService userService;

    @PostMapping
    public ResponseEntity<JobResponse> createJob(@RequestBody CreateJobRequest request){
        return ResponseEntity.ok(jobService.createJob(request));
    }

    @GetMapping
    public ResponseEntity<List<Job>> getAllJobs(){
        return ResponseEntity.ok(jobService.getAllJobs());
    }

    @GetMapping("/recommended")
    public ResponseEntity<List<Job>> getRecommendedJobs(org.springframework.security.core.Authentication authentication) throws Exception {
        User user = userService.findUserByEmail(authentication.getName());
        return ResponseEntity.ok(jobService.getRecommendedJobs(user.getId()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Job> getJobById(@PathVariable Long id) throws Exception {
        return ResponseEntity.ok(jobService.getJobById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Job> updateJob(@PathVariable Long id, @RequestBody Job job) throws Exception {
        return ResponseEntity.ok(jobService.updateJob(id, job));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteJob(@PathVariable Long id) {
        jobService.deleteJob(id);
        return ResponseEntity.ok("Job deleted successfully");
    }
}
